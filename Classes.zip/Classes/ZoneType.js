// ZoneType.js
export const ZoneType = {
    House: "House",
    Forest: "Forest",
    Colosseum: "Colosseum",
    Roads: "Roads",
    RoyalForges: "RoyalForges",
    RoyalShipyards: "RoyalShipyards",
    Knights: "Knights",
};
