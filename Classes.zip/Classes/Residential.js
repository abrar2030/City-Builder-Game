// Residential.js
import { Zone } from "./Zone.js";

export class Residential extends Zone {
  constructor(type, cost, capacity, satisfaction) {
    super(type, cost);
    this.capacity = capacity;
    this.satisfaction = satisfaction;
    this.people_living_in_house = 0;
  }

  returnCapacity() {
      return this.capacity;
  }

  returnSatisfaction(){
    return this.satisfaction;
  }
}
