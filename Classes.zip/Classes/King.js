import { City } from "./City.js";

export class King {
  constructor(city) {
    this.Capital = 0;
    this.Satisfaction = 0.0;
    this.City = city
  }


  build(building, posX, posY) {
    console.log(`Building a ${building.constructor.name}`);
    //have to change the matrix inside with the thing being built
    this.City.build(building, posX, posY);
    return true;
  }

  returnPositionInCity(i,j){
    return this.City.getTypeOfZone(i,j);
  }

  destroy(building) {
    // Logic to destroy a building, returns true on success
    this.City.typeOfZone = 0;
    this.Capital += 10;
    console.log(`Destroying a ${building.constructor.name}`);
    return true;
  }

  upgrade(building) {
    // Logic to upgrade a building, returns true on success
    console.log(`Upgrading a ${building.constructor.name}`);
    return true;
  }
}
