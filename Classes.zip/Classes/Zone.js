// Zone.js
import { ZoneType } from "./ZoneType.js";

export class Zone {
  constructor(type, cost) {
    if (!Object.values(ZoneType).includes(type)) {
      throw new Error("Invalid zone type");
    }
    this.type = type;
    this.cost = cost;
  }

  type(){
    return this.type;
  }
  upgrade() {
    this.cost += 100;
    return true;
  }

  build() {
    if (this.cost > 0) {
      return true;
    }
    return false;
  }

  demolish() {
    return cost*0.7;
  }
}
