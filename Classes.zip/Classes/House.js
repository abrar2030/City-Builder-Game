// House.js
import { Residential } from "./Residential.js";

export class House extends Residential {
  constructor(type, cost, capacity, people_living_in_house, satisfaction, pic_type, count){
    super(type, cost, capacity, satisfaction);
    this.workplace_references = [];
    this.unemployed = people_living_in_house;
    this.people_living_in_house = people_living_in_house;
    this.is_in_zone = false;
    this.is_Upgraded = false;
    this.is_connected = false;
    this.job_close = false;
    this.pic_type = pic_type;
    this.count = count;
  }

  toString() {
    return `<br>Zone - Type: ${this.type},<br>Cost: ${this.cost},<br>Capacity: ${this.capacity},<br>People Living in House: ${this.people_living_in_house},<br>Satisfaction: ${this.satisfaction}`;
  }

  upgrade(){
    this.capacity +=50;
    this.is_Upgraded = true;

  }

  connect(){
    this.is_connected = true;
  }

  job_close(bool){
    if(bool == true){
      if(this.job_close){

      }else{
        this.job_close = true;
        if(this.satisfaction + 10 > 100){
          this.satisfaction = 100;
        }else{
          this.satisfaction +=10;
        }
      }
    }else{
      if(this.job_close){
        this.job_close = false;
        this.satisfaction -=10;
      }
    }
  }
}

//road automatic around residential