// Colosseum.js
import { Service } from "./Service.js";

export class Colosseum extends Service {

    //needs the name, cost, worker_num,statisfaction, range, maintenance_fee  
    constructor(type, cost, capacity, amountOfWorkers, radius, maintenance_fee, multiplier, order, count) {
        super(type, cost, capacity, amountOfWorkers);
        this.radius = radius; // Assuming radius is an attribute, not a method based on your description
        this.maintenance_fee = 25;
        this.multiplier = multiplier;
        this.is_connected = false;
        this.order = order;
        this.count = count;
    }

    change_worker_count(count_of_workers){
        //implement later
    }

    hire(num) {
        super.hire(num); 
      }

    toString() {
        return `Zone - Type: ${this.type},<br>Cost: ${this.cost},<br>Capacity: ${this.capacity},<br>Amount of Workers: ${this.amountOfWorkers},<br>Radius: ${this.radius},<br>Maintenance Fee: ${this.maintenance_fee},<br>Multiplier: ${this.multiplier}, ${this.is_connected}`;    
    }

    connect(){
        this.is_connected = true;
    }
    
}
