// RoyalShipyards.js
import { Industrial } from "./Industrial.js";

export class RoyalShipyards extends Industrial {
  constructor(type, cost, capacity, amountOfWorkers) {
    super(type, cost);
    this.amountOfWorkers = amountOfWorkers;
    this.capacity = capacity;
    this.is_Upgraded = false;
    this.is_connected = false;
  }

  hire(num) {
    super.hire(num); 
  }
  toString() {
    return `Royal Shipyards - Type: ${this.type},<br>Cost: ${this.cost},<br>Capacity: ${this.capacity},<br>Amount of Workers: ${this.amountOfWorkers}`;  }

    upgrade(){
      this.capacity +=50;
      this.is_Upgraded = true;
    }

    connect(){
      this.is_connected = true;

    }
}
