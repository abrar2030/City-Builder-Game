// Industrial.js
import { Zone } from "./Zone.js";

export class Industrial extends Zone {
  constructor(type, cost, capacity, amountOfWorkers) {
    super(type, cost);
    this.capacity = capacity;
    this.amountOfWorkers = amountOfWorkers;
  }

  hire(num){
    this.amountOfWorkers += num;
  }
}
