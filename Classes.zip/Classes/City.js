export class City {
  constructor(matrix) {
    this.amount = 0; // Array to hold Zone objects
    this.typeOfZone = matrix;
    this.amount_of_residential=0;
  }

  typeOfZone_get(){
    return this.typeOfZone;
  }
  getPrice() {
    return 0;
  }

  get_amount_of_residential(){
    return this.amount_of_residential;
  }

  getTypeOfZone(i,j){
    return this.typeOfZone[i][j];
  }

  calculate_population(){
    let population =0;
    for (let i = 0; i < this.typeOfZone.length; i++) {
      for (let j = 0; j < this.typeOfZone[i].length; j++) {
          let zone_type = this.typeOfZone[i][j];
          if(zone_type != 0 && zone_type.type == "House"){
            population += zone_type.people_living_in_house;
          }
        }
    }
    return population;
  }


  getSatisfaction() {
    const residentialZones = this.typeOfZone.filter(
      (zone) => zone instanceof Residential
    );
    const totalSatisfaction = residentialZones.reduce(
      (total, zone) => total + zone.satisfaction,
      0
    );
    return residentialZones.length > 0
      ? totalSatisfaction / residentialZones.length
      : 0;
  }

  getAmount() {
    // Return the number of zones
    return this.typeOfZone.length;
  }

  build(reference_to_instance_of_building,PosX,PosY){
    this.typeOfZone[PosX][PosY] = reference_to_instance_of_building;
  }

  get_unemployment_count(){
      let totalUnemployed = 0;

      for (let row of this.typeOfZone) {
          for (let cell of row) {
            if (cell != 0 && cell.type == "House" && cell.unemployed) {
                  totalUnemployed += cell.unemployed;
              }
          }
      }
      return totalUnemployed;
  }

  count_service_zone_workers(){
    let array = ["Colosseum","Forest"];
    let totalService =0;
    for (let row of this.typeOfZone) {
      for (let cell of row) {
        if (cell != 0 && array.includes(cell.type)) {
              totalService += cell.amountOfWorkers;
          }
      }
  }
    return totalService;
  }

  count_industrial_zone_workers(){
    let array = ["RoyalForges", "RoyalShipyards",];
    let totalIndustrial =0;
    for (let row of this.typeOfZone) {
      for (let cell of row) {
        if (cell != 0 && array.includes(cell.type)) {
          totalIndustrial += cell.amountOfWorkers;
          }
      }
  }
    return totalIndustrial;
  }

  //make it so that people will go to work if there are jobs available
  //make a function to put all references of the jobs in arrays. Service or ind
  //Go through each. Fill the service, fill the industrial. One by one. As long as there are still people and space to work.
  //Another function to know if there are enough spaces to work. In the city class? Also make a tax collection thing from every place. 

  return_array_of_industrial(){
    let industrial_array = []
    let array = ["RoyalForges", "RoyalShipyards"];
    let worker_capacity_left =0;


    for (let row of this.typeOfZone) {
      for (let cell of row) {
        if (cell != 0 && array.includes(cell.type) && cell.is_connected) {
          industrial_array.push(cell);
          worker_capacity_left += cell.capacity-cell.amountOfWorkers;
          }
      }
  }
    return {
      array: industrial_array,
      count: worker_capacity_left
    }
  }

  return_array_of_service(){
    let service_array = []
    let array = ["Colosseum","Forest"];
    let worker_capacity_left =0;

    for (let row of this.typeOfZone) {
      for (let cell of row) {
        if (cell != 0 && array.includes(cell.type) && cell.is_connected) {
          service_array.push(cell);
          worker_capacity_left += cell.capacity-cell.amountOfWorkers;
          }
      }
  }
    return {
      array: service_array,
      count: worker_capacity_left
    }
  }

  return_houses_array(){
    let house_array = []
    for (let row of this.typeOfZone) {
      for (let cell of row) {
        if (cell != 0 && (cell.type == "House" || cell.type == "Manison")) {
          house_array.push(cell);
          }
      }
  }
    return house_array;
  }

  return_jobs_left(){
    let total_left =0;
    for (let row of this.typeOfZone) {
      for (let cell of row) {
        if (cell != 0 && cell.type != "House") {
          total_left += cell.capacity - cell.amountOfWorkers;
          }
      }
    }
    return total_left;
  }

  return_percentage_workers(){
    let service_zone_workers = this.count_service_zone_workers();
    let industrial_zone_workers = this.count_industrial_zone_workers();
    let pop = this.calculate_population();
    if(pop == 0){
      return 0;
    }

    if(service_zone_workers == 0 && industrial_zone_workers != 0){
      return 10;
    }
    
    if(service_zone_workers != 0 && industrial_zone_workers == 0){
      return 10;
    }
    
    if(service_zone_workers == 0 && industrial_zone_workers == 0){
      return 20;
    }

    if(industrial_zone_workers == service_zone_workers){
      return -10;
    }
    
    return 10*Math.max(service_zone_workers/this.calculate_population,industrial_zone_workers/this.calculate_population);
  }

  
  check_two_by_two_residential(row,col){
      if (row < 0 || row + 1 >= this.typeOfZone.length || col < 0 || col + 1 >= this.typeOfZone[0].length) {
          return false;
      }
  
      for (let i = row; i <= row + 1; i++) {
          for (let j = col; j <= col + 1; j++) {
              if (this.typeOfZone[i][j].type !== 'House') {
                  return false; 
              }
          }
      }

      let one_in_zone = false;

      for (let i = row; i <= row + 1; i++) {
        for (let j = col; j <= col + 1; j++) {
          if(this.typeOfZone[i][j].is_in_zone){
            one_in_zone = true;
          }
        }
      }


      if(!one_in_zone){
      for (let i = row; i <= row + 1; i++) {
        for (let j = col; j <= col + 1; j++) {
          this.typeOfZone[i][j].is_in_zone = true;
        }
      }
    }

      return true; 
  }

  find_residential_zones(){
    for (let i = 0; i < this.typeOfZone.length; i++) {
      for (let j = 0; j < this.typeOfZone[i].length; j++) {
        if(this.typeOfZone[i][j].type == "House"){
          this.check_two_by_two_residential(i,j);
        }
      }
    }
  }

  increase_satisfaction_around_special_zones() {
    const specialZones = ['Knights', 'Forest', 'Colosseum','RoyalForges','RoyalShipyards']; // Types that trigger satisfaction increases

    for (let i = 0; i < this.typeOfZone.length; i++) {
      for (let j = 0; j < this.typeOfZone[i].length; j++) {
        if (specialZones.includes(this.typeOfZone[i][j]?.type)) {
          this.increase_satisfaction(i, j);
        }
      }
    }
  }

  increase_satisfaction(row, col) {
    const delta = 10;

    for (let i = row - 1; i <= row + 1; i++) {
      for (let j = col - 1; j <= col + 1; j++) {
        console.log("j,i:= " ,j , i);
        if (i >= 0 && i < this.typeOfZone.length && j >= 0 && j < this.typeOfZone[i].length) {
          if (this.typeOfZone[i][j] !== 0 && ['House', 'Mansion'].includes(this.typeOfZone[i][j].type)) {
            this.typeOfZone[i][j].satisfaction += delta;
            console.log(`Increased satisfaction of ${this.typeOfZone[i][j].type} at (${i}, ${j}) to ${this.typeOfZone[i][j].satisfaction}`);
          }
        }
      }
    }
  }


  move_in(satisfaction) {
    if (satisfaction > 55) {
      for (let row of this.typeOfZone) {
        for (let cell of row) {
          if (cell !== 0 && cell.type === "House") {
            let potentialNewPopulation = cell.people_living_in_house + (satisfaction - cell.people_living_in_house);
  
            if (potentialNewPopulation > cell.capacity) {
              cell.people_living_in_house = cell.capacity; // Set to max capacity if exceeded
            } else {
              cell.people_living_in_house = potentialNewPopulation; // Otherwise, update to the new population
            }
          }
        }
      }
    }
  }

  
 checkAndConnect() {
  const rows = this.typeOfZone.length;
  const cols = this.typeOfZone[0].length;

  for (let i = 0; i < rows; i++) {
      for (let j = 0; j < cols; j++) {
          if (this.typeOfZone[i][j].type == "Roads") {
              [[i - 1, j], [i + 1, j], [i, j - 1], [i, j + 1]].forEach(([x, y]) => {
                  if (x >= 0 && x < rows && y >= 0 && y < cols) { // Check bounds
                      if (this.typeOfZone[x][y] !== 0 && this.typeOfZone[x][y].type !== 'Roads' && !this.typeOfZone[x][y].is_connected) {
                        console.log("Type that is being connected: " + this.typeOfZone[x][y].type);
                        this.typeOfZone[x][y].connect();
                        console.log("Is it connected now? = " + this.typeOfZone[x][y].is_connected);
                      }
                  }
              });
          }
      }
  }
}

  check_if_connects_roads(z,x,y){
    if(z == 0){
      return true;
    }

    const directions = [
      [-1, 0], 
      [1, 0],  
      [0, -1], 
      [0, 1],  
      [-1, -1],
      [-1, 1],  
      [1, 1]   
  ];

  for (let [dx, dy] of directions) {
      let nx = x + dx;
      let ny = y + dy;
      if (nx >= 0 && nx < this.typeOfZone.length && ny >= 0 && ny < this.typeOfZone[nx].length) {
          if (this.typeOfZone[nx][ny] !== 0 && this.typeOfZone[nx][ny].type === 'Roads') {
              return true; 
          }
      }
  }

  return false; 
  }
  
  check_if_workplace_close(){
    //finish it tomorrow
    let numRows = this.typeOfZone.length;
    let numCols = this.typeOfZone[0].length;

    for (let i = 0; i < numOfRows; i++) {
    for (let j = 0; j < numOfCols; j++) {
        let iMin = Math.max(0, i - 1);
        let iMax = Math.min(numOfRows - 1, i + 1);
        let jMin = Math.max(0, j - 1);
        let jMax = Math.min(numOfCols - 1, j + 1);

        // loop through the above numbers safely
        for (let innerI = iMin; innerI <= iMax; innerI++) {
            for (let innerJ = jMin; innerJ <= jMax; innerJ++) {
                if (i != innerI && j != innerJ && this.typeOfZone[i][j]) {

                }
            }
        }
    }
}
  }

//fix later
  build_on_residential(satisfaction){
    for (let i = 0; i < this.typeOfZone.length; i++) {
      for (let j = 0; j < this.typeOfZone[i].length; j++) {
        if(this.typeOfZone[i][j].type == "House" && this.typeOfZone[i][j].capacity == 0 && population > 0){
          this.typeOfZone[i][j] = new House("House", buildingTypes["House"].price, 100, satisfaction, satisfaction);
          population -= Math.min();
        }
      }
    }
  }

  check_unemployment_rate(x,y){
    console.log("Satisfaction before " + this.typeOfZone[x][y].satisfaction);
    if(this.typeOfZone[x][y].people_living_in_house == this.typeOfZone[x][y].unemployed){
      this.typeOfZone[x][y].satisfaction -= 10;
    }else if (this.typeOfZone[x][y].unemployed == 0){
      this.typeOfZone[x][y].satisfaction =+ 10;
    }else{ 
      this.typeOfZone[x][y].satisfaction -=5;
    }
    console.log("Satisfaction after " + this.typeOfZone[x][y].satisfaction);

  }

  calculate_satisfaction(){
    let count =0;
    let satisfaction = 0
    for (let i = 0; i < this.typeOfZone.length; i++) {
      for (let j = 0; j < this.typeOfZone[i].length; j++) {
        if(this.typeOfZone[i][j].type == "House"){
          console.log("Satisfaction before " + this.typeOfZone[i][j].satisfaction);

          this.check_unemployment_rate(i,j);
          console.log("Satisfaction after " + this.typeOfZone[i][j].satisfaction);

          satisfaction += this.typeOfZone[i][j].satisfaction;
          count++;
        }
      }
    }
    if(count == 0){
      return 50;
    }
    return satisfaction/count;
  }

  can_build_in_fourbyfour(startX, startY){
    
    let numRows = this.typeOfZone.length;
    let numCols = this.typeOfZone[0].length;
    return startX >= 0 && startY >= 0 && 
           startX + 1 < numRows && startY + 1 < numCols &&
           this.typeOfZone[startX][startY] === 0 && 
           this.typeOfZone[startX][startY + 1] === 0 && 
           this.typeOfZone[startX + 1][startY] === 0 && 
           this.typeOfZone[startX + 1][startY + 1] === 0;
  }

  destroy_colosseum(cnt){
    for (let i = 0; i < this.typeOfZone.length; i++) {
      for (let j = 0; j < this.typeOfZone[i].length; j++) {
        if(this.typeOfZone[i][j].type == "Colosseum" && this.typeOfZone[i][j].count == cnt){
          this.typeOfZone[i][j] = 0;
        }
      }
    }    
  }

   isValid_destroy_roadt(matrixData, rowIndex, colIndex) {
    let numRows = matrixData.length;
    let numCols = matrixData[0].length;
  
    let roadsCount = 0;
    let buildingsCount = 0;
  
    if (rowIndex > 0) {
      let cell = matrixData[rowIndex - 1][colIndex];
      if (cell && cell.type === 'Roads') {
        roadsCount++;
      } else if (cell) {
        buildingsCount++;
      }
    }
  
    if (rowIndex < numRows - 1) {
      let cell = matrixData[rowIndex + 1][colIndex];
      if (cell && cell.type === 'Roads') {
        roadsCount++;
      } else if (cell) {
        buildingsCount++;
      }
    }
  
    if (colIndex > 0) {
      let cell = matrixData[rowIndex][colIndex - 1];
      if (cell && cell.type === 'Roads') {
        roadsCount++;
      } else if (cell) {
        buildingsCount++;
      }
    }
  
    if (colIndex < numCols - 1) {
      let cell = matrixData[rowIndex][colIndex + 1];
      if (cell && cell.type === 'Roads') {
        roadsCount++;
      } else if (cell) {
        buildingsCount++;
      }
    }
  
    let centerCell = matrixData[rowIndex][colIndex];
    if (centerCell && centerCell.type === 'Roads') {
      roadsCount++;
    } else if (centerCell) {
      buildingsCount++;
    }
  
    if (roadsCount === 1 && buildingsCount === 0) {
      return true;
    }
  
    return false;
  }
  

  isValidDestroyRoad(rowIndex, colIndex) {
    let numRows = this.typeOfZone.length;
    let numCols = this.typeOfZone[0].length;

    let roadsCount = 0;
    let buildingsCount = 0;

    // Define the coordinates for the 3x3 area
    const coordinates = [
      [rowIndex - 1, colIndex], 
      [rowIndex, colIndex - 1],    [rowIndex, colIndex + 1],
      [rowIndex + 1, colIndex]
    ];

    // Check each cell in the 3x3 area
    for (const [r, c] of coordinates) {
      if (r >= 0 && r < numRows && c >= 0 && c < numCols) {
        const cell = this.typeOfZone[r][c];
        if (cell && cell.type === 'Roads') {
          roadsCount++;
        } else if (cell && cell.type) {
          buildingsCount++;
        }
      }
    }
    console.log(roadsCount);
    console.log(buildingsCount);
    // Return true if there is exactly one road and no other buildings around the cell
    return roadsCount === 1 || roadsCount === 0 && buildingsCount === 0;
  }

  destroy_house(cnt){
    for (let i = 0; i < this.typeOfZone.length; i++) {
      for (let j = 0; j < this.typeOfZone[i].length; j++) {
        if(this.typeOfZone[i][j].type == "House" && this.typeOfZone[i][j].count == cnt){
          this.typeOfZone[i][j] = 0;
        }
      }
    }    
  }


  calculateMaintenanceFees() {
    let totalMaintenanceFee = 0;

    for (let i = 0; i < this.typeOfZone.length; i++) {
      for (let j = 0; j < this.typeOfZone[i].length; j++) {
        const cell = this.typeOfZone[i][j];
        if (cell && cell.maintenance_fee) {
          totalMaintenanceFee += cell.maintenance_fee;
        }
      }
    }
    console.log(totalMaintenanceFee);
    return totalMaintenanceFee;
  }
}



    
