// Forest.js
import { Service } from "./Service.js";

export class Forest extends Service {
  constructor(type, cost, capacity, amountOfWorkers) {
    super(type, capacity, cost);
    this.amountOfWorkers = amountOfWorkers;
    this.is_connected = false;
    this.maintenance = 100;
  }
  
  hire(num) {
    super.hire(num); 
  }

  toString() {
    return `Zone - Type: ${this.type},<br>Cost: ${this.cost},<br>Capacity: ${this.capacity},<br>Amount of Workers: ${this.amountOfWorkers}`; 
  }

  connect(){
    this.is_connected = true;
  }
}
