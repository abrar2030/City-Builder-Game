// RoyalWorkshop.js
import { Industrial } from "./Industrial.js";

export class RoyalWorkshop extends Industrial {
  // Additional properties or methods specific to Royal Workshop can be added here

  connect(){
    this.is_connected = false;
  }
}


