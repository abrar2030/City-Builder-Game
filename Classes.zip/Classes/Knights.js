import { Service } from "./Service.js";

export class Knights extends Service {
  constructor(type, cost, capacity, amountOfWorkers, radius, maintenance_fee, multiplier) {
    super(type, cost, capacity,amountOfWorkers);
    this.radius = radius;
    this.maintenance_fee = 100;
    this.capacity = capacity;
    this.multiplier = multiplier;
    this.is_connected = false;

  }


  getRadiusKnights() {
    return this.radius;
  }

  hire(num) {
    super.hire(num); 
  }

  toString() {
    return `Knights - Type: ${this.type},<br>Cost: ${this.cost},<br>Capacity: ${this.capacity},<br>Amount of Workers: ${this.amountOfWorkers},<br>Radius: ${this.radius},<br>Maintenance Fee: ${this.maintenance_fee},<br>Multiplier: ${this.multiplier}`;  
  }

  connect(){
    this.is_connected = true;
  }

}
