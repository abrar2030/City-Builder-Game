// Vehicles.js
import { Service } from "./Service.js";

export class Vehicles extends Service {
  // Additional properties or methods specific to Vehicles can be added here
}
