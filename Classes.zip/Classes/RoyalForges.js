// RoyalForges.js
import { Industrial } from "./Industrial.js";

export class RoyalForges extends Industrial {
  // Additional properties or methods specific to Royal Forges can be added here
  constructor(type, cost, capacity, amountOfWorkers) {
    super(type, cost);
    this.amountOfWorkers = amountOfWorkers;
    this.capacity = capacity;
    this.is_Upgraded = false;
    this.is_connected = false;
  }

  toString() {
    return `Royal Forges - Type: ${this.type},<br>Cost: ${this.cost},<br>Capacity: ${this.capacity},<br>Amount of Workers: ${this.amountOfWorkers}`;  }

    upgrade(){
      this.capacity +=50;
      this.is_Upgraded = true;
    }
    
    connect(){
      this.is_connected = true;
    }
}
