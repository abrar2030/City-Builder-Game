// Roads.js
import { Service } from "./Service.js";

export class Roads extends Service {
  // Additional properties or methods specific to Roads can be added here
  constructor(type, cost, amountOfWorkers, maintenance_fee) {
    super(type, cost, amountOfWorkers);
    this.maintenance_fee = 50;
    this.amountOfWorkers=0;
    }

  findClosestWorkplace(matrix, housePosition) {
    const rows = matrix.length;
    const cols = matrix[0].length;
    const directions = [[1, 0], [0, 1], [-1, 0], [0, -1]]; // Down, Right, Up, Left
    let queue = [housePosition];
    let visited = new Set([housePosition.join(',')]);
    let closestWorkplace = null;
    let minDistance = Infinity;
  
    while (queue.length > 0) {
        let [x, y] = queue.shift();
  
        // Check if the current cell is a workplace and closer than the previously found workplace
        if (matrix[x][y] === 'W') {
            let distance = Math.abs(x - housePosition[0]) + Math.abs(y - housePosition[1]);
            if (distance < minDistance) {
                closestWorkplace = [x, y];
                minDistance = distance;
            }
        }
  
        // Explore all possible directions
        for (let [dx, dy] of directions) {
            let nx = x + dx, ny = y + dy;
            let position = nx + ',' + ny;
            // Check bounds and if the position can be traversed and hasn't been visited
            if (nx >= 0 && nx < rows && ny >= 0 && ny < cols && matrix[nx][ny] !== '0' && !visited.has(position)) {
                visited.add(position);
                queue.push([nx, ny]);
            }
        }
    }
  
    return closestWorkplace;
  }
  toString() {
    return `Roads - Type: ${this.type},<br>Cost: ${this.cost},<br>Amount of Workers: ${this.amountOfWorkers},<br>Maintenance Fee: ${this.maintenance_fee}`;  }
  
}

