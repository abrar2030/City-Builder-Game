// test/Roads.test.js
import { Roads } from '../Classes/Roads';
import { Service } from '../Classes/Service';

// Mocking the Service class if needed
jest.mock('../Classes/Service', () => {
  return {
    Service: class {
      constructor(type, cost, amountOfWorkers) {
        this.type = type;
        this.cost = cost;
        this.amountOfWorkers = amountOfWorkers;
      }
    }
  };
});

describe('Roads class', () => {
  let roads;

  beforeEach(() => {
    roads = new Roads('Roads', 100, 5, 50);
  });

  test('should be an instance of Service', () => {
    expect(roads).toBeInstanceOf(Service);
  });

  test('should return null if no workplace is found', () => {
    const matrix = [
      ['0', '0', '0', '0', '0'],
      ['0', 'H', '0', '0', '0'],
      ['0', '0', '0', '0', '0'],
      ['0', '0', '0', '0', '0'],
      ['0', '0', '0', '0', '0']
    ];
    const housePosition = [1, 1];
    const closestWorkplace = roads.findClosestWorkplace(matrix, housePosition);
    expect(closestWorkplace).toBeNull();
  });
});
