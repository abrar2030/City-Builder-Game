// test/RoyalForges.test.js
import { RoyalForges } from '../Classes/RoyalForges';
import { Industrial } from '../Classes/Industrial';

// Mocking the Industrial class if needed
jest.mock('../Classes/Industrial', () => {
  return {
    Industrial: class {
      constructor(type, cost) {
        this.type = type;
        this.cost = cost;
      }
    }
  };
});

describe('RoyalForges class', () => {
  let royalForges;

  beforeEach(() => {
    royalForges = new RoyalForges('Royal Forges', 2000, 100, 30);
  });

  test('should be an instance of Industrial', () => {
    expect(royalForges).toBeInstanceOf(Industrial);
  });

  test('should initialize with correct values', () => {
    expect(royalForges.type).toBe('Royal Forges');
    expect(royalForges.cost).toBe(2000);
    expect(royalForges.capacity).toBe(100);
    expect(royalForges.amountOfWorkers).toBe(30);
    expect(royalForges.is_Upgraded).toBe(false);
    expect(royalForges.is_connected).toBe(false);
  });

  test('should return correct string representation', () => {
    const expectedString = `Royal Forges - Type: Royal Forges,<br>Cost: 2000,<br>Capacity: 100,<br>Amount of Workers: 30`;
    expect(royalForges.toString()).toBe(expectedString);
  });

  test('should upgrade the royal forges', () => {
    royalForges.upgrade();
    expect(royalForges.capacity).toBe(150); // Initial capacity 100 + 50 after upgrade
    expect(royalForges.is_Upgraded).toBe(true);
  });

  test('should connect the royal forges', () => {
    royalForges.connect();
    expect(royalForges.is_connected).toBe(true);
  });
});
