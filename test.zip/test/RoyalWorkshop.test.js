// test/RoyalWorkshop.test.js
import { RoyalWorkshop } from '../Classes/RoyalWorkshop';
import { Industrial } from '../Classes/Industrial';

// Mocking the Industrial class if needed
jest.mock('../Classes/Industrial', () => {
  return {
    Industrial: class {
      constructor(type, cost) {
        this.type = type;
        this.cost = cost;
        this.amountOfWorkers = 0;
        this.capacity = 0;
      }
      hire(num) {
        this.amountOfWorkers += num;
      }
    }
  };
});

describe('RoyalWorkshop class', () => {
  let royalWorkshop;

  beforeEach(() => {
    royalWorkshop = new RoyalWorkshop('Royal Workshop', 2500, 150, 40);
  });

  test('should be an instance of Industrial', () => {
    expect(royalWorkshop).toBeInstanceOf(Industrial);
  });

  test('should connect the royal workshop', () => {
    royalWorkshop.connect();
    expect(royalWorkshop.is_connected).toBe(false);
  });

});
