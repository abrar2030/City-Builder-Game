// test/Residential.test.js
import { Residential } from '../Classes/Residential';
import { Zone } from '../Classes/Zone';

// Mocking the Zone class if needed
jest.mock('../Classes/Zone', () => {
  return {
    Zone: class {
      constructor(type, cost) {
        this.type = type;
        this.cost = cost;
      }
    }
  };
});

describe('Residential class', () => {
  let residential;

  beforeEach(() => {
    residential = new Residential('Residential', 500, 4, 80);
  });

  test('should be an instance of Zone', () => {
    expect(residential).toBeInstanceOf(Zone);
  });

  test('should initialize with correct values', () => {
    expect(residential.type).toBe('Residential');
    expect(residential.cost).toBe(500);
    expect(residential.capacity).toBe(4);
    expect(residential.satisfaction).toBe(80);
    expect(residential.people_living_in_house).toBe(0);
  });

  test('should return correct capacity', () => {
    expect(residential.returnCapacity()).toBe(4);
  });

  test('should return correct satisfaction', () => {
    expect(residential.returnSatisfaction()).toBe(80);
  });
});
