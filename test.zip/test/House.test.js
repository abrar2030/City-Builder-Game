// test/House.test.js
import { House } from '../Classes/House';
import { Residential } from '../Classes/Residential';

// Mocking the Residential class if needed
jest.mock('../Classes/Residential', () => {
  return {
    Residential: class {
      constructor(type, cost, capacity, satisfaction) {
        this.type = type;
        this.cost = cost;
        this.capacity = capacity;
        this.satisfaction = satisfaction;
      }
    }
  };
});

describe('House class', () => {
  let house;

  beforeEach(() => {
    house = new House('House', 100, 4, 3, 50);
  });

  test('should be an instance of Residential', () => {
    expect(house).toBeInstanceOf(Residential);
  });

  test('should initialize with correct values', () => {
    expect(house.type).toBe('House');
    expect(house.cost).toBe(100);
    expect(house.capacity).toBe(4);
    expect(house.people_living_in_house).toBe(3);
    expect(house.satisfaction).toBe(50);
    expect(house.unemployed).toBe(3);
    expect(house.is_in_zone).toBe(false);
    expect(house.is_Upgraded).toBe(false);
    expect(house.is_connected).toBe(false);
    expect(house.job_close).toBe(false);
  });

  test('should return correct string representation', () => {
    const expectedString = `<br>Zone - Type: House,<br>Cost: 100,<br>Capacity: 4,<br>People Living in House: 3,<br>Satisfaction: 50`;
    expect(house.toString()).toBe(expectedString);
  });

  test('should upgrade the house correctly', () => {
    house.upgrade();
    expect(house.capacity).toBe(54); // Initial capacity 4 + 50 after upgrade
    expect(house.is_Upgraded).toBe(true);
  });

  test('should connect the house', () => {
    house.connect();
    expect(house.is_connected).toBe(true);
  });
});
