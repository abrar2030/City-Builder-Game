// test/Zone.test.js
import { Zone } from '../Classes/Zone';
import { ZoneType } from '../Classes/ZoneType';

describe('Zone class', () => {
  let zone;

  beforeEach(() => {
    zone = new Zone(ZoneType.House, 1000);
  });

  test('should initialize with correct values', () => {
    expect(zone.type).toBe(ZoneType.House);
    expect(zone.cost).toBe(1000);
  });

  test('should throw error for invalid zone type', () => {
    expect(() => {
      new Zone('InvalidType', 1000);
    }).toThrow('Invalid zone type');
  });

  test('should upgrade the zone and increase the cost', () => {
    const result = zone.upgrade();
    expect(result).toBe(true);
    expect(zone.cost).toBe(1100);
  });

  test('should build the zone if cost is greater than 0', () => {
    const result = zone.build();
    expect(result).toBe(true);
  });

  test('should not build the zone if cost is 0', () => {
    const zeroCostZone = new Zone(ZoneType.House, 0);
    const result = zeroCostZone.build();
    expect(result).toBe(false);
  });

});
