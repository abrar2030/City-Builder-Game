// test/Knights.test.js
import { Knights } from '../Classes/Knights';
import { Service } from '../Classes/Service';

// Mocking the Service class if needed
jest.mock('../Classes/Service', () => {
  return {
    Service: class {
      constructor(type, cost, capacity, amountOfWorkers) {
        this.type = type;
        this.cost = cost;
        this.capacity = capacity;
        this.amountOfWorkers = amountOfWorkers;
      }
      hire(num) {
        this.amountOfWorkers += num;
      }
    }
  };
});

describe('Knights class', () => {
  let knights;

  beforeEach(() => {
    knights = new Knights('Knights', 1500, 40, 10, 3, 300, 1.5);
  });

  test('should be an instance of Service', () => {
    expect(knights).toBeInstanceOf(Service);
  });

  test('should return correct radius', () => {
    expect(knights.getRadiusKnights()).toBe(3);
  });

  test('should connect the knights', () => {
    knights.connect();
    expect(knights.is_connected).toBe(true);
  });

  test('should hire workers', () => {
    knights.hire(15);
    expect(knights.amountOfWorkers).toBe(25);
  });
});
