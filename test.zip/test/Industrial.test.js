// test/Industrial.test.js
import { Industrial } from '../Classes/Industrial';
import { Zone } from '../Classes/Zone';

// Mocking the Zone class if needed
jest.mock('../Classes/Zone', () => {
  return {
    Zone: class {
      constructor(type, cost) {
        this.type = type;
        this.cost = cost;
      }
    }
  };
});

describe('Industrial class', () => {
  let industrial;

  beforeEach(() => {
    industrial = new Industrial('Industrial', 800, 100, 20);
  });

  test('should be an instance of Zone', () => {
    expect(industrial).toBeInstanceOf(Zone);
  });

  test('should initialize with correct values', () => {
    expect(industrial.type).toBe('Industrial');
    expect(industrial.cost).toBe(800);
    expect(industrial.capacity).toBe(100);
    expect(industrial.amountOfWorkers).toBe(20);
  });

  test('should hire workers', () => {
    industrial.hire(30);
    expect(industrial.amountOfWorkers).toBe(50);
  });
});
