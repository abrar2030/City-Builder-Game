const { City } = require('../Classes/City');

describe('City class', () => {
  let matrix;
  let city;

  beforeEach(() => {
    matrix = [
      [{ type: 'House', people_living_in_house: 4, capacity: 5, unemployed: 1, satisfaction: 60 }, 0],
      [0, { type: 'Colosseum', capacity: 10, amountOfWorkers: 5, is_connected: false }],
    ];
    city = new City(matrix);
  });

  test('should return type of zone matrix', () => {
    expect(city.typeOfZone_get()).toBe(matrix);
  });

  test('should get the type of zone at a specific position', () => {
    expect(city.getTypeOfZone(0, 0).type).toBe('House');
    expect(city.getTypeOfZone(1, 1).type).toBe('Colosseum');
  });

  test('should calculate total population', () => {
    expect(city.calculate_population()).toBe(4);
  });

  test('should return total number of zones', () => {
    expect(city.getAmount()).toBe(2);
  });

  test('should build a new zone at a specific position', () => {
    const newBuilding = { type: 'Forest', capacity: 8, amountOfWorkers: 3, is_connected: false };
    city.build(newBuilding, 1, 0);
    expect(city.getTypeOfZone(1, 0)).toBe(newBuilding);
  });

  test('should return total unemployed count', () => {
    expect(city.get_unemployment_count()).toBe(1);
  });

  test('should return total service zone workers count', () => {
    expect(city.count_service_zone_workers()).toBe(5);
  });

  test('should return total industrial zone workers count', () => {
    expect(city.count_industrial_zone_workers()).toBe(0);
  });

  test('should return array of industrial zones', () => {
    expect(city.return_array_of_industrial().array.length).toBe(0);
  });

  test('should return array of houses', () => {
    expect(city.return_houses_array().length).toBe(1);
  });

  test('should return percentage of workers', () => {
    expect(city.return_percentage_workers()).toBe(10);
  });

  test('should check if roads connect to a specific zone', () => {
    expect(city.check_if_connects_roads(city.getTypeOfZone(1, 1), 1, 1)).toBe(false);
  });

  test('should calculate satisfaction correctly', () => {
    expect(city.calculate_satisfaction()).toBe(55);
  });

});
