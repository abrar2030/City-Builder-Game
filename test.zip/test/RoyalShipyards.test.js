// test/RoyalShipyards.test.js
import { RoyalShipyards } from '../Classes/RoyalShipyards';
import { Industrial } from '../Classes/Industrial';

// Mocking the Industrial class if needed
jest.mock('../Classes/Industrial', () => {
  return {
    Industrial: class {
      constructor(type, cost) {
        this.type = type;
        this.cost = cost;
        this.amountOfWorkers = 0;
        this.capacity = 0;
      }
      hire(num) {
        this.amountOfWorkers += num;
      }
    }
  };
});

describe('RoyalShipyards class', () => {
  let royalShipyards;

  beforeEach(() => {
    royalShipyards = new RoyalShipyards('Royal Shipyards', 3000, 200, 50);
  });

  test('should be an instance of Industrial', () => {
    expect(royalShipyards).toBeInstanceOf(Industrial);
  });

  test('should initialize with correct values', () => {
    expect(royalShipyards.type).toBe('Royal Shipyards');
    expect(royalShipyards.cost).toBe(3000);
    expect(royalShipyards.capacity).toBe(200);
    expect(royalShipyards.amountOfWorkers).toBe(50);
    expect(royalShipyards.is_Upgraded).toBe(false);
    expect(royalShipyards.is_connected).toBe(false);
  });

  test('should return correct string representation', () => {
    const expectedString = `Royal Shipyards - Type: Royal Shipyards,<br>Cost: 3000,<br>Capacity: 200,<br>Amount of Workers: 50`;
    expect(royalShipyards.toString()).toBe(expectedString);
  });

  test('should upgrade the royal shipyards', () => {
    royalShipyards.upgrade();
    expect(royalShipyards.capacity).toBe(250); // Initial capacity 200 + 50 after upgrade
    expect(royalShipyards.is_Upgraded).toBe(true);
  });

  test('should connect the royal shipyards', () => {
    royalShipyards.connect();
    expect(royalShipyards.is_connected).toBe(true);
  });

  test('should hire workers', () => {
    royalShipyards.hire(20);
    expect(royalShipyards.amountOfWorkers).toBe(70); // Initial amount of workers 50 + 20 after hire
  });
});
