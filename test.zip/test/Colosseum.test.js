// test/Colosseum.test.js
import { Colosseum } from '../Classes/Colosseum';
import { Service } from '../Classes/Service';

// Mocking the Service class if needed
jest.mock('../Classes/Service', () => {
  return {
    Service: class {
      constructor(type, cost, capacity, amountOfWorkers) {
        this.type = type;
        this.cost = cost;
        this.capacity = capacity;
        this.amountOfWorkers = amountOfWorkers;
      }
      hire(num) {
        this.amountOfWorkers += num;
      }
    }
  };
});

describe('Colosseum class', () => {
  let colosseum;

  beforeEach(() => {
    colosseum = new Colosseum('Colosseum', 1000, 50, 10, 5, 200, 2, 1);
  });

  test('should be an instance of Service', () => {
    expect(colosseum).toBeInstanceOf(Service);
  });

  test('should connect the colosseum', () => {
    colosseum.connect();
    expect(colosseum.is_connected).toBe(true);
  });

  test('should hire workers', () => {
    colosseum.hire(5);
    expect(colosseum.amountOfWorkers).toBe(15);
  });
});
