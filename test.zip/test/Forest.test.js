// test/Forest.test.js
import { Forest } from '../Classes/Forest';
import { Service } from '../Classes/Service';

// Mocking the Service class if needed
jest.mock('../Classes/Service', () => {
  return {
    Service: class {
      constructor(type, cost, capacity) {
        this.type = type;
        this.cost = cost;
        this.capacity = capacity;
        this.amountOfWorkers = 0; // Add this to avoid undefined errors
      }
      hire(num) {
        this.amountOfWorkers += num;
      }
    }
  };
});

describe('Forest class', () => {
  let forest;

  beforeEach(() => {
    forest = new Forest('Forest', 500, 30, 5);
  });

  test('should be an instance of Service', () => {
    expect(forest).toBeInstanceOf(Service);
  });

  test('should connect the forest', () => {
    forest.connect();
    expect(forest.is_connected).toBe(true);
  });

  test('should hire workers', () => {
    forest.hire(10);
    expect(forest.amountOfWorkers).toBe(15);
  });
});
