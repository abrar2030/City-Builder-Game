// test/King.test.js
import { King } from '../Classes/King';
import { City } from '../Classes/City';
import { House } from '../Classes/House'; // Ensure the path is correct

// Mocking the City class if needed
jest.mock('../Classes/City', () => {
  return {
    City: class {
      constructor(matrix) {
        this.typeOfZone = matrix;
      }
      build(building, posX, posY) {
        this.typeOfZone[posX][posY] = building;
      }
      getTypeOfZone(i, j) {
        return this.typeOfZone[i][j];
      }
    }
  };
});

// Mocking the House class for testing purposes
jest.mock('../Classes/House', () => {
  return {
    House: class {
      constructor() {
        // Remove setting the name property to avoid TypeError
      }
    }
  };
});

describe('King class', () => {
  let city;
  let king;
  let house;

  beforeEach(() => {
    city = new City([[0, 0], [0, 0]]);
    king = new King(city);
    house = new House();
  });

  test('should initialize with correct values', () => {
    expect(king.Capital).toBe(0);
    expect(king.Satisfaction).toBe(0.0);
    expect(king.City).toBe(city);
  });

  test('should build a building', () => {
    const result = king.build(house, 0, 1);
    expect(result).toBe(true);
    expect(king.City.getTypeOfZone(0, 1)).toBe(house);
  });

  test('should return position in city', () => {
    king.build(house, 0, 1);
    expect(king.returnPositionInCity(0, 1)).toBe(house);
  });

  test('should upgrade a building', () => {
    const result = king.upgrade(house);
    expect(result).toBe(true);
  });
});
